#! /bin/zsh

outDir=$1
inizio=$2

if [[ ! "$outDir" ]]; then
  outDir=/tmp
fi

if [[ ! "$inizio" ]]; then
  inizio=1
fi

cd $outDir
#%(playlist_id)s
youtube-dl -i -f 18 -o '%(playlist_index)s - %(title)s.%(ext)s' --extract-audio --audio-format mp3 --add-metadata --playlist-start $inizio 'https://www.youtube.com/playlist?list=PL1SHutkY63dOOnDEJUjARcB9hou5_dW4k'

#cd $outDir/Chiara
#mkdir out
#for file in *.mp4; do
  #o=${file:r};
  #if [[ ! -e "out/$o.avi" ]]; then
    #ffmpeg -i "$file" -vcodec libxvid -acodec libmp3lame "out/$o.avi";
  #fi
  #rm -f "$file"
#done

#cd $outDir
#youtube-dl -i -f best -o 'Chiara/%(playlist_index)s - %(title)s.%(ext)s' --playlist-start $inizio 'https://www.youtube.com/playlist?list=PL1SHutkY63dOOnDEJUjARcB9hou5_dW4k'
