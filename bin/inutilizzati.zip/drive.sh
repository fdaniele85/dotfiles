#!/usr/bin/env zsh

zparseopts -D -E m=mount u=umount

#bic=$(mount | grep "${HOME}/GDrive Bicocca")
gm=$(mount | grep "${HOME}/GDrive Gmail")


if [[ $mount[1] == "-m" ]]; then
  # if [[ -z "$bic" ]]; then
  #   echo "Monto GDrive Bicocca"
  #   /usr/bin/google-drive-ocamlfuse $1 "${HOME}/GDrive Bicocca"&
  # fi
  if [[ -z "$gm" ]]; then
    echo "Monto GDrive Gmail"
    /usr/bin/google-drive-ocamlfuse $1 -label gmail "${HOME}/GDrive Gmail"&
  fi
elif [[ $umount[1] == "-u" ]]; then
  # if [[ ! -z "$bic" ]]; then
  #   echo "Smonto GDrive Bicocca"
  #   fusermount -u "${HOME}/GDrive Bicocca"
  # fi
  if [[ ! -z "$gm" ]]; then
    echo "Smonto GDrive Gmail"
    fusermount -u "${HOME}/GDrive Gmail"
  fi
else
  # if [[ -z "$bic" ]]; then
  #   echo "Monto GDrive Bicocca"
  #   /usr/bin/google-drive-ocamlfuse $1 "${HOME}/GDrive Bicocca"&
  # else
  #   echo "Smonto GDrive Bicocca"
  #   fusermount -u "${HOME}/GDrive Bicocca"
  # fi

  if [[ -z "$gm" ]]; then
    echo "Monto GDrive Gmail"
    /usr/bin/google-drive-ocamlfuse $1 -label gmail "${HOME}/GDrive Gmail"&
  else
    echo "Smonto GDrive Gmail"
    fusermount -u "${HOME}/GDrive Gmail"
  fi
fi
