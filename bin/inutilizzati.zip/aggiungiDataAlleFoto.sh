#! /bin/zsh

for file in *.jpg; do
  echo $file;
  x=$(exiftool -ImageSize $file |sed 's/.*: //;s/x.*//');
  x=$((x-1200));
  echo $x;
  dat=$(exiftool -DateTimeOriginal -S "$file" | sed 's/DateTimeOriginal: *//');
  dat=$(echo $dat | sed 's/ /\n/');
  echo $dat;
  echo;
  /usr/bin/convert "$file" -font /usr/share/fonts/fonts-go/Go-Regular.ttf -pointsize 128 -fill white -annotate +$x+150 "$dat"  "new-${file}";
done
