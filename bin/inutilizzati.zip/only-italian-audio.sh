#! /bin/zsh

#typeset -A assoc


for input in $*; do
    track=$(mkvinfo $input | grep 'Traccia numero\|Tipo traccia\|Lingua' | grep -A1 -B1 'Tipo traccia.*audio' | grep -B2 'Lingua: ita' | head -n 1 |sed 's/.*mkvextract: //;s/ *).*//')

    mkvmerge -o "out_$input" --atracks $track "$input"
    #mkvinfo $input | grep 'Traccia numero\|Tipo traccia\|Lingua' | grep -A1 -B1 'Tipo traccia.*audio' | grep -B2 'Lingua: ita'
    #echo $track

    #echo -n "$input. Che traccia è italiana? "
    #read track
    #assoc[$input]=$track
done


for input in $*; do
    #echo $input. $assoc[$input]
done
