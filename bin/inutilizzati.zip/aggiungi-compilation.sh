#! /bin/zsh

zparseopts -D -E n:=name d:=dir o:=out

name=$name[2]
dir=$dir[2]
out=$out[2]

if [[ -z "$name" ]]; then
	echo "Option name (-n) mandatory"
	exit 1
fi

if [[ -z "$dir" ]]; then
	for d in /media/daniele/*; do
		b=$(basename "$d")
		if [[ "$b" != "Elements" ]]; then
			dir="$d"
			break
		fi
	done
fi

if [[ -z "$dir" ]]; then
	echo "Wrong dir"
	exit 1
fi



if [[ -z "$out" ]]; then
	if [[ -e ~/Dropbox/Temporanei/catalogo.csv ]]; then
		out=~/Dropbox/Temporanei/catalogo.csv
	fi
fi
if [[ -z "$out" ]]; then
	echo "Wrong $out"
	exit 1
fi


if [[ ! -e "$out" ]]; then
	echo "Disco,File" > "$out"
fi

echo "Aggiungo:"
for file in $dir/*; do
	b=$(basename "$file" | sed 's/,//g')
	echo "$name,$b" | tee -a "$out"
done