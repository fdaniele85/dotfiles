#! /bin/zsh

multiplo=''

for file in *; do
	disc=$(exiftool -PartOfSet "$file" | sed 's/.*: //;s_/.*__');
	if ((disc > 1)); then
		multiplo='si'
	fi
done

echo "Multiplo: $multiplo"

for file in *; do
	disc=$(exiftool -PartOfSet "$file" | sed 's/.*: //;s_/.*__');
	disc=$(printf "%02d" $disc);
	track=$(exiftool -track "$file" | sed 's/.*: //;s_/.*__');
	track=$(printf "%02d" $track);
	if [[ "$multiplo" == "si" ]]; then
		echo "Disc $disc/$track$file";
	else
		echo "$track$file";
	fi
done | sort

read "scelta?Proseguire? "

if [[ "$scelta" == "y" || "$scelta" == "Y" ]]; then
	for file in *; do
		disc=$(exiftool -PartOfSet "$file" | sed 's/.*: //;s_/.*__');
		disc=$(printf "%02d" $disc);
		track=$(exiftool -track "$file" | sed 's/.*: //;s_/.*__');
		track=$(printf "%02d" $track);
		if [[ "$multiplo" == "si" ]]; then
			mkdir -p "Disc $disc"
			mv "$file" "Disc $disc/$track$file";
		else
			mv "$file" "$track$file";
		fi
	done
fi
