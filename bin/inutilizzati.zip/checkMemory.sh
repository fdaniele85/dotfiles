#! /bin/zsh

name=$1
pid=$(ps aux | grep "$name" | grep -v grep | grep -v checkMemory | awk '{print $2;}');
while [[ ! -z "$pid" ]]; do 
	pmap $pid | tail -n 1
	sleep 1
	pid=$(ps aux | grep "$name" | grep -v grep | grep -v checkMemory | awk '{print $2;}');
done