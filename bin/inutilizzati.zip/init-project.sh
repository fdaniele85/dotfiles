#! /bin/zsh

name=$1

if [[ -z "$name" ]]; then
	echo name mandatory
	exit 1
fi

git init
sed "s/NAME/$name/" /home/daniele/Dropbox/linux_files/scripts/conf/CMakeLists.txt > CMakeLists.txt
cp /home/daniele/Dropbox/linux_files/scripts/conf/gitignore .gitignore
mkdir external
cd external
git submodule add https://github.com/fdaniele85/dferone.git
git submodule add https://github.com/amrayn/easyloggingpp.git
git submodule add https://github.com/louisdx/cxx-prettyprint.git

