#! /usr/bin/python

import os
import sys
import re
import json
import argparse
import csv
import random


parser = argparse.ArgumentParser(description='test')
parser.add_argument("inputs", nargs='+', help="Input files")
parser.add_argument("-o", "--out", help="Output file")
parser.add_argument("--type", help="Type regex")
parser.add_argument("-i", "--iterazioni", help="Iterazioni", required=True)

args = parser.parse_args()
inputs = args.inputs
out = args.out
typeRegex = args.type
iterazioni = int(args.iterazioni)

if typeRegex is None:
    typeRegex = "_\d+\.ris$"

v = {}
var = {}
types = {}
media = {}

for dr in inputs:
    v[dr] = {}
    var[dr] = {}
    media[dr] = {}

    for fil in os.listdir(dr):
        if re.search("ris$", fil):
            typ = re.sub(typeRegex, '', fil)

            if typ not in v[dr]:
                v[dr][typ] = {}
                v[dr][typ]['totali'] = 0
                var[dr][typ] = {}
                media[dr][typ] = {}

            types[typ] = 1

            try:
                #print os.path.join(dr, fil)
                f=open(os.path.join(dr, fil))

                sys.stderr.write(fil+'\n')
                a = json.load(f)


                v[dr][typ]['totali'] += 1

                x = None
                for q in a['Algorithm']['Incumbents']:
                	if q['Iteration'] <= iterazioni and q['Cost']['Feasible']:
                		x = q['Cost']['Cost']
                		print "qui: ", x

                if x is None:
                	x = a['Solution']['Cost']

                arg = 'Cost'
               	v[dr][typ][arg] = v[dr][typ].get(arg, 0.0) + x
               	delta = x - media[dr][typ].get(arg, 0.0)
               	media[dr][typ][arg] = media[dr][typ].get(arg, 0.0) + delta/v[dr][typ]['totali']
               	var[dr][typ][arg] = var[dr][typ].get(arg, 0.0) + delta * (x - media[dr][typ][arg])

            except ValueError, e:
            	pass

            f.close()



def sostituisci(x):
    return re.sub("_[0-9.]*$", "", x)
    #return x.replace("/", "")#.replace("_", "\\_")

def getKey(x):
    if x.find("Random") >= 0:
        return re.sub("x(\d+)N(\d+)t", r"N\2x\1t", x)
    else:
        return x.lower()


writer = csv.writer(sys.stdout,delimiter=',')

if out:
    csvfile = open(out, 'w')
    writer = csv.writer(csvfile, delimiter=',')

righe = []

algs = map(lambda x : sostituisci(str(x)), sorted(v.keys()))

fieldnames = ['']

for alg in algs:
	fieldnames.append(alg)
	fieldnames.append("")


righe.append(fieldnames)
#writer.writerow(fieldnames)

fieldnames = ['']

for alg in algs:
	fieldnames.append('Cost')
	fieldnames.append("")

righe.append(fieldnames)

fieldnames = ['']

for alg in algs:
	fieldnames.append("Average")
	fieldnames.append("Standard deviation")

righe.append(fieldnames)
#writer.writerow(fieldnames)

for typ in sorted(types, key=getKey):
	row = []
	toPrint = True
	row.append(typ)

	for dr in sorted(v.keys()):
		if typ in v[dr] and v[dr][typ]['totali'] > 0:
			div = v[dr][typ]['totali']

			q='Cost'
			row.append(v[dr][typ][q] / div)
			if div > 1:
				row.append(var[dr][typ][q] / (div -1))
			else:
				row.append(var[dr][typ][q])
		else:
			toPrint = False
			row.append("")
			row.append("")


		righe.append(row)

if len(righe) > 2:
	for row in righe:
		writer.writerow(row)
	for i in range(0, 5):
		writer.writerow([])