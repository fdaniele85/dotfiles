#! /bin/zsh

for f in "$@"; do
  echo "Modificando la data di $f"
  exiftool -api quicktimeutc=1 "-FileModifyDate<QuickTime:CreateDate" -overwrite_original "$f"
done
