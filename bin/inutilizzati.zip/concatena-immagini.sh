#! /bin/zsh

min=1e15
identify $* | sed 's/^.*[[:digit:]][[:digit:]]*x\([[:digit:]]*\)[[:space:]].*/\1/' | while read size; do
	if ((size < min)); then
		min=$size
	fi
done
echo "Min size: $min"

convert -splice 25x0+0+0 +append $* -resize x$min - | convert - -chop 25x0+0+0 out.jpg