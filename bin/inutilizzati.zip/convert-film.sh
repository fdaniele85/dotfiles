#! /usr/bin/env zsh

#source /home/daniele/Dropbox/linux_files/shell/lock.zsh
#lock_or_die backup-rasp-el || eexit "Impossibile acquisire il lock"

local to_exit=''

#trap ctrl_c INT SIGINT

function convert_file {
  origin=$1
  echo "Analizzo $origin"
  out=$(ssh raspberry "/home/pi/scripts/chromecastize.sh --check '$origin'" < /dev/null)
  echo $out
  not_playable=$(echo $out | grep 'video length')
  if [[ ! -z "$not_playable" ]]; then
    f=$(basename "$origin")
    f="/tmp/$f"
    if [[ -d /media/daniele/Elements/esterno_grande ]]; then
      f=$(echo "$origin" | sed 's;/media/Esterno/Video/;/media/daniele/Elements/esterno_grande/Video/;')
    fi
    rsync -a --progress --partial "raspberry:'$origin'" "$f"
    /home/daniele/Dropbox/linux_files/scripts/chromecastize.sh "$f" | tee /tmp/out
    out=$(grep 'conversion succeeded' /tmp/out)
    if [[ ! -z "$out" ]]; then
      rm -f "$f.bak"
      f=$(echo ${f:r}*)
      ext=${f:e}
      ssh raspberry "rm -f '$origin'" < /dev/null
      origin="${origin:r}.$ext"
      rsync -a --progress --partial "$f" "raspberry:'$origin'"
      ssh raspberry "chmod 0644 '$origin'"
      if [[ ! -d /media/daniele/Elements/esterno_grande ]]; then
        rm -f "$f"
      fi
    fi
  fi
  echo
}

function ctrl_c() {
  echo "Uscirò appena sarà sincronizzato il prossimo file"
  to_exit=1
}


ssh raspberry 'find /media/Esterno/Video/[FS]* -type d -print' | sed 's_/media/Esterno/Video/__' | while read d; do
  if [[ -d /media/daniele/Elements/esterno_grande ]]; then
    if [[ ! -d "/media/daniele/Elements/esterno_grande/Video/$d" ]]; then
      mkdir -p /media/daniele/Elements/esterno_grande/Video/"$d"
      echo /media/daniele/Elements/esterno_grande/Video/"$d"
    fi
  fi
done


IFS=$'\n' films=($(ssh raspberry 'find /media/Esterno/Video/[FS]* -type f -print | grep -Fvf /home/pi/.chromecastize/processed_files' | sort))
for origin in $films; do
  convert_file "$origin"
  if [[ $to_exit ]]; then
    echo "Esco"
    return 1
  fi
done
