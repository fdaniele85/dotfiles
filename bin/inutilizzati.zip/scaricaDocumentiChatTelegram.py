#! /usr/bin/python3

from pyrogram import Client, filters
import sys
import time

quanti = 1000
if len(sys.argv) > 1:
	quanti = int(sys.argv[1])

app = Client("Downloader_n", api_id=1161983, api_hash="7c08518ab26e5f0e25f8619a77f838f0")

app.start()
status = app.send_message("me", "Inizio scaricamento")

for message in app.get_chat_history("me"):
	if quanti == 0:
		break

	last = -20
	start = time.time()

	if (message.media and (message.document or message.audio)):
		quanti -= 1	
		name=''
		if message.document:
			print("Scarico file ", message.document.file_name)
			name = message.document.file_name
		else:
			print("Scarico file ", message.audio.file_name)
			name = message.audio.file_name

		async def stampa(current, total):
			global last
			seconds = time.time() - start
			rimanenti = (seconds * total / current) - seconds
			s = "{:d}. {:s}. {:.2f}MB of {:.2f}MB ({:.2f}%). Rimanenti {}.".format(quanti, name, current/1e06, total/1e06, 100*(current/total), time.strftime("%M:%S", time.gmtime(rimanenti)))
			print("\r{}".format(s), end='')

			if int(100*(current/total)) >= last + 10:
				await app.edit_message_text("me", status.id, s)
				last = int(100*(current/total))

		#out = message.download(progress=stampa, file_name="/tmp/downloads/")
		out = message.download(progress=stampa, file_name="/home/daniele/Scaricati/Completi/")
		
		if out is not None:
			print("\nFile di output: ", out)
			app.delete_messages("me", message.id)
		print("")

app.delete_messages("me", status.id)
app.stop()
