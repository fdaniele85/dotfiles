#! /bin/zsh

dat=$(date "+%Y%m%d")

for d in $*; do
	if [[ -d "$d" ]]; then
		mv "$d" "$dat - $d"
		rsync -a --progress --remove-source-files -s "$dat - $d" "raspberry:/media/Esterno/LibriInPausa/"
		rmdir "$dat - $d"
	fi
done