#!/usr/bin/env bash
# Usage: pause-guard.sh pausename -- command [args...]
# Env:
#   PAUSE_MODE=skip (default) -> se il file esiste, NON esegue il comando (logga) e esce 0
#   PAUSE_MODE=wait           -> aspetta che il file sparisca; se scatta TIMEOUT NON esegue (logga) e esce 0
#   WAIT_POLL=5               -> secondi tra poll (fallback se inotifywait non c'è)
#   WAIT_TIMEOUT=0            -> 0 = attesa infinita
set -euo pipefail

PAUSE="${1:?Usage: $0 PAUSE_NAME -- command [args...]}"
shift
[ "${1:-}" = "--" ] && shift
[ "$#" -gt 0 ] || { echo "Error: missing command" >&2; exit 64; }

if [[ -n "$XDG_RUNTIME_DIR" ]]; then
    DIR="$XDG_RUNTIME_DIR/pause"
else
    DIR="/run/pause"
fi

MODE="${PAUSE_MODE:-skip}"
POLL="${WAIT_POLL:-5}"
TIMEOUT="${WAIT_TIMEOUT:-0}"

# logging
LOG_FILE="${LOG_FILE:-/dev/null}"
log(){ printf "%s [%s] %s\n" "$(date '+%F %T')" "pause-guard" "$*" | tee -a "$LOG_FILE"; }

if [ "$MODE" = "skip" ]; then
  if [ -e "$DIR/$PAUSE" ]; then
    log "skip: paused by file '$PAUSE'"
    exit 0
  fi
  exec env LOG_FILE="$LOG_FILE" "$@"
fi

if [ "$MODE" = "wait" ]; then
  # se non in pausa, eseguo subito
  if [ ! -e "$DIR/$PAUSE" ]; then
    exec env LOG_FILE="$LOG_FILE" "$@"
  fi

  start=$(date +%s)
  if command -v inotifywait >/dev/null 2>&1; then
    # attendo eventi sulla directory; dopo ogni evento ricontrollo l'esistenza
    while [ -e "$PAUSE" ]; do
      inotifywait -q -e delete -e move -e attrib -e close_write "$(dirname "$PAUSE")" >/dev/null 2>&1 || true
      if [ "$TIMEOUT" -gt 0 ]; then
        now=$(date +%s)
        if [ $((now-start)) -ge "$TIMEOUT" ]; then
          log "skip: timeout ${TIMEOUT}s reached while paused by '$PAUSE'"
          exit 0
        fi
      fi
    done
  else
    # fallback: polling
    while [ -e "$DIR/$PAUSE" ]; do
      sleep "$POLL"
      if [ "$TIMEOUT" -gt 0 ]; then
        now=$(date +%s)
        if [ $((now-start)) -ge "$TIMEOUT" ]; then
          log "skip: timeout ${TIMEOUT}s reached while paused by '$PAUSE'"
          exit 0
        fi
      fi
    done
  fi
  exec env LOG_FILE="$LOG_FILE" "$@"
fi

echo "pause-guard: unknown PAUSE_MODE '$MODE' (use 'skip' or 'wait')" >&2
exit 64
