#! /bin/bash

import=''
while getopts i opt; do
  case $opt in
    i)
      import=1
      ;;
    \?)
      echo "Error"
      exit 1
  esac
done

original=$(echo *.flac)
shnsplit -f *.cue -t "%n - %p - %t" -o "flac flac -s -8 -o %f -" *.flac
if [[ $? -eq 0 ]]; then
  rm -f "$original"
  rm -f 00*
  cuetag *.cue *.flac

  if [[ $import ]]; then
    beet import .
  fi
else
  rm -f [012]*.flac
fi
