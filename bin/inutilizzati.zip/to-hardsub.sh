#! /bin/zsh

for input in $*; do
  mkvinfo $input | grep 'Traccia numero\|Tipo traccia\|Lingua\|Nome'

  echo -n "Che traccia contiene i sottotitoli? "
  read track
  mkvextract tracks "$input" $track:/tmp/ita.srt

  ffmpeg -i "$input" -vf subtitles=/tmp/ita.srt -c:v libx264 -c:a libvorbis -crf 18 "out_$input"
done
